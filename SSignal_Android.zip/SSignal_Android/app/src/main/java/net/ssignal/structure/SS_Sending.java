package net.ssignal.structure;

public class SS_Sending {

    public String 讯宝地址, 文本, 文件路径;
    public byte 指令;
    public long 发送序号, 存储时间;
    public short 宽度, 高度;
    public byte 文件字节数组[], 视频预览图片数据[], 秒数, 群编号;

}
