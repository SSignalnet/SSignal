package net.ssignal.protocols;

public class Group {

    public short 新讯宝数量;

}
