package net.ssignal.structure;

public class Domain {

    public String 英语, 本国语;

}
