package net.ssignal.protocols;

public class GroupMember {

    public String 英语讯宝地址, 本国语讯宝地址, 昵称, 主机名;
    public short 位置号;
    public byte 角色;
    public int 临时编号;
    public Group 所属的群;

}
