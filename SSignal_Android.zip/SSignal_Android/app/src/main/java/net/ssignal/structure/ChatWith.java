package net.ssignal.structure;

import net.ssignal.protocols.Contact;
import net.ssignal.protocols.Group_Large;
import net.ssignal.protocols.Group_Small;

public class ChatWith {

    public Contact 讯友或群主;
    public Group_Small 小聊天群;
    public Group_Large 大聊天群;

}
