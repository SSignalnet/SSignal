package net.ssignal.structure;

public class GroupWithNewSS {
    public long 编号, 时间, 撤回的讯宝[];
    public int 新讯宝数量, 撤回的讯宝数量;
}
