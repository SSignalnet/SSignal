package net.ssignal.structure;

public class HostName {

    public String 英语讯宝地址, 主机名;

}
