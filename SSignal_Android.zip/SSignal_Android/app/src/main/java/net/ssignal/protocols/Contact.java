package net.ssignal.protocols;

public class Contact {

    public String 英语讯宝地址, 本国语讯宝地址, 备注, 标签一, 标签二, 主机名;
    public short 位置号, 新讯宝数量;
    public int 临时编号;
    public boolean 拉黑;
    public long 头像更新时间;

}
