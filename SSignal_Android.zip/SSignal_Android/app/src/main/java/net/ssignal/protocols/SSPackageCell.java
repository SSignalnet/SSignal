package net.ssignal.protocols;

public class SSPackageCell {

    byte 类型, 长度信息字节数;
    Object 数据;
    String 标签;

}
