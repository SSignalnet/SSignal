package net.ssignal.protocols;

public class Group_Large extends Group {

    public long 编号, 图标更新时间 = 0, 最新讯宝的发送时间 = 0, 检查时间 = 0;
    public String 主机名, 英语域名, 本国语域名, 子域名, 名称, 连接凭据;
    public byte 我的角色;

}
