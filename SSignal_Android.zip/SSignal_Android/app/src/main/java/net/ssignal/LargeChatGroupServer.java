package net.ssignal;

public class LargeChatGroupServer {

    String 子域名;
    boolean 无连接凭据 = false;
    Thread 线程;

    public LargeChatGroupServer(String 子域名1) {
        子域名 = 子域名1;
    }

}
